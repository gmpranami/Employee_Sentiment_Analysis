# Employee Sentiment Analysis — Minimal End-to-End (Tasks 1–6)

GitHub Repository Link: https://github.com/gmpranami/Employee_Sentiment_Analysis

This repository implements the **Employee Sentiment Analysis** assignment covering Tasks 1–6 with a minimal, reproducible pipeline.

---

## 📊 Summary

### Top 3 Positive Employees (Latest Month: 2011-12)
1. **kayne.coulter@enron.com** — Score: +5  
2. **patti.thompson@enron.com** — Score: +5  
3. **eric.bass@enron.com** — Score: +4  

### Top 3 Negative Employees (Latest Month: 2011-12)
1. **bobette.riner@ipgdirect.com** — Score: 0  
2. **john.arnold@enron.com** — Score: 2  
3. **johnny.palmer@enron.com** — Score: 2  

### 🚩 Flight-Risk Employees
- bobette.riner@ipgdirect.com  
- johnny.palmer@enron.com  
- lydia.delgado@enron.com  
- patti.thompson@enron.com  
- rhonda.denton@enron.com  
- sally.beck@enron.com  

### 🔑 Key Insights
- **Consistently high performers:** Don Baughman, Lydia Delgado, John Arnold, and Sally Beck show repeated positive scores across multiple months.  
- **Volatile sentiment:** Some employees (e.g., Bobette Riner, Johnny Palmer, Patti Thompson) appear both in top positive and negative lists, indicating fluctuating sentiment.  
- **Flight risks:** Six employees crossed the threshold of ≥4 negative emails in rolling 30-day windows, suggesting possible disengagement or stress periods.  
- **Trendline:** The linear regression shows sentiment fluctuates significantly month-to-month but has pockets of improvement driven by specific employees.  

### ✅ Recommendations
- **Proactive HR check-ins** with flight-risk employees to prevent attrition.  
- **Recognition & rewards** for consistently positive contributors (Don Baughman, Lydia Delgado, John Arnold, Sally Beck).  
- **Investigate root causes** of volatility in sentiment (Bobette Riner, Patti Thompson) — may be workload or role-specific stressors.  
- **Refine sentiment model** (upgrade from TextBlob) to capture nuanced employee tone and context more accurately.  

---

## 📂 Contents
- `Employee_Sentiment_Analysis.ipynb` — main notebook (end-to-end pipeline).
- `src/minimal_e2e.py` — Python script version for CLI runs.
- `visualizations/` — generated charts (created on run).
- `labeled_data.csv` — sentiment-labeled dataset.
- `employee_scores.csv` — monthly employee sentiment scores.
- `flight_risks.txt` — employees flagged as potential flight risks.
- `REPORT.md` — detailed methodology and results writeup.

---

## 🚀 Quickstart
1. Place the dataset in the root folder as either:
   - `test(in).csv` (default), or
   - `test.csv` (per the spec).  
   **Required columns:** `Subject, body, date, from`
2. Run the notebook:
   ```bash
   jupyter notebook Employee_Sentiment_Analysis.ipynb
